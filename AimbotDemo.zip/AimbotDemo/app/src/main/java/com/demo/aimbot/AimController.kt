package com.demo.aimbot

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import kotlin.math.*

object AimController {
    var service: AimAccessibilityService? = null
    private var lastX = -1f
    private var lastY = -1f

    fun aim(tx: Float, ty: Float, cx: Float, cy: Float) {
        val svc = service ?: return
        val dx = tx - cx
        val dy = ty - cy
        if (sqrt(dx * dx + dy * dy) < 8f) return

        val stepX = cx + dx * Config.smoothness
        val stepY = cy + dy * Config.smoothness

        val path = Path().apply {
            if (lastX < 0) moveTo(cx, cy) else moveTo(lastX, lastY)
            lineTo(stepX, stepY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 16))
            .build()
        svc.dispatchGesture(gesture, null, null)
        lastX = stepX
        lastY = stepY
    }

    fun reset() { lastX = -1f; lastY = -1f }
}
