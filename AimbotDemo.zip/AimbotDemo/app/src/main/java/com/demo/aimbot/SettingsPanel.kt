package com.demo.aimbot

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsPanel(private val context: Context) {

    fun build(): View {
        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 30, 30, 30)
            background = GradientDrawable().apply {
                setColor(Color.argb(230, 20, 20, 26))
                cornerRadius = 20f
            }
        }

        // title
        panel.addView(TextView(context).apply {
            text = "⚙ Aimbot Settings"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, 0, 20)
        })

        // === CROSSHAIR STYLE ===
        panel.addView(label("Crosshair Style"))
        val styles = arrayOf("cross", "dot", "circle", "tstyle")
        val styleSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, styles)
            setSelection(styles.indexOf(Config.crosshairStyle))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    Config.crosshairStyle = styles[pos]
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        panel.addView(styleSpinner)

        // === SLIDERS ===
        panel.addView(slider("Crosshair Size", 5f, 60f, Config.crosshairSize) {
            Config.crosshairSize = it
        })
        panel.addView(slider("Crosshair Gap", 2f, 30f, Config.crosshairGap) {
            Config.crosshairGap = it
        })
        panel.addView(slider("Thickness", 1f, 10f, Config.crosshairThickness) {
            Config.crosshairThickness = it
        })
        panel.addView(slider("FOV Radius", 100f, 800f, Config.fovRadius) {
            Config.fovRadius = it
        })
        panel.addView(slider("Smoothness", 0.01f, 1f, Config.smoothness) {
            Config.smoothness = it
        })
        panel.addView(slider("Prediction", 0f, 0.5f, Config.predictionFactor) {
            Config.predictionFactor = it
        })
        panel.addView(slider("Confidence Min", 0.1f, 0.95f, Config.confidenceMin) {
            Config.confidenceMin = it
        })

        // === COLOR PICKER (sederhana: preset) ===
        panel.addView(label("Crosshair Color"))
        val colors = arrayOf(
            Color.rgb(0, 255, 100), Color.rgb(255, 50, 50),
            Color.rgb(50, 150, 255), Color.rgb(255, 255, 255),
            Color.rgb(255, 200, 0)
        )
        val colorRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in colors) {
            val btn = View(context).apply {
                layoutParams = LinearLayout.LayoutParams(60, 60).apply { marginEnd = 10 }
                background = GradientDrawable().apply {
                    setColor(c)
                    cornerRadius = 30f
                }
                setOnClickListener { Config.crosshairColor = c }
            }
            colorRow.addView(btn)
        }
        panel.addView(colorRow)

        // === TOGGLES ===
        panel.addView(toggle("Show FOV", Config.fovVisible) { Config.fovVisible = it })
        panel.addView(toggle("Show Box", Config.showBox) { Config.showBox = it })
        panel.addView(toggle("Visibility Check", Config.visibilityCheck) { Config.visibilityCheck = it })
        panel.addView(toggle("Team Check", Config.teamCheck) { Config.teamCheck = it })
        panel.addView(toggle("Aimbot Enabled", Config.aimbotEnabled) { Config.aimbotEnabled = it })

        // === TARGET PART ===
        panel.addView(label("Target Part"))
        val parts = arrayOf("head", "body", "nearest")
        val partSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, parts)
            setSelection(parts.indexOf(Config.targetPart))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    Config.targetPart = parts[pos]
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        panel.addView(partSpinner)

        // scroll wrapper
        val scroll = ScrollView(context).apply {
            addView(panel)
            layoutParams = LinearLayout.LayoutParams(700, 1200)
        }
        return scroll
    }

    private fun label(text: String) = TextView(context).apply {
        this.text = text
        setTextColor(Color.rgb(180, 200, 255))
        textSize = 12f
        setPadding(0, 15, 0, 5)
    }

    private fun slider(label: String, min: Float, max: Float, value: Float, onChange: (Float) -> Unit): View {
        val wrapper = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 10, 0, 10)
        }
        val lbl = TextView(context).apply {
            text = "$label: %.2f".format(value)
            setTextColor(Color.WHITE)
            textSize = 11f
        }
        val seek = SeekBar(context).apply {
            this.max = 100
            progress = (((value - min) / (max - min)) * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = min + (max - min) * (p / 100f)
                    lbl.text = "$label: %.2f".format(v)
                    onChange(v)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        wrapper.addView(lbl)
        wrapper.addView(seek)
        return wrapper
    }

    private fun toggle(label: String, initial: Boolean, onChange: (Boolean) -> Unit): View {
        val cb = CheckBox(context).apply {
            text = label
            isChecked = initial
            setTextColor(Color.WHITE)
            textSize = 12f
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
        return cb
    }
}
