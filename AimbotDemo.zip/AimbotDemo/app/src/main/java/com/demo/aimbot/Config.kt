package com.demo.aimbot

import android.graphics.Color

object Config {
    // === CROSSHAIR ===
    var crosshairStyle = "cross"     // "cross" | "dot" | "circle" | "tstyle"
    var crosshairSize = 30f          // panjang garis
    var crosshairGap = 10f           // jarak dari center
    var crosshairThickness = 4f
    var crosshairColor = Color.rgb(0, 255, 100)
    var crosshairLockColor = Color.rgb(255, 50, 50)  // warna saat lock target
    var crosshairDot = true
    var crosshairDotRadius = 5f
    var crosshairOutline = true      // outline hitam biar kelihatan di semua background

    // === FOV ===
    var fovRadius = 400f
    var fovColor = Color.argb(80, 255, 255, 255)
    var fovVisible = true

    // === AIMBOT ===
    var aimbotEnabled = false
    var aimKey = "always"            // "always" | "hold" | "toggle"
    var smoothness = 0.15f           // 0.01 = slow, 1.0 = instant snap
    var predictionFactor = 0.165f    // lead target
    var targetPart = "head"          // "head" | "body" | "nearest"
    var maxDistance = 500f           // studs/meter
    var visibilityCheck = true       // raycast wall check
    var teamCheck = true
    var confidenceMin = 0.5f         // threshold model

    // === BOX ===
    var showBox = true
    var boxColor = Color.rgb(255, 50, 50)
    var boxThickness = 4f
    var showLabel = true

    // === GUI ===
    var panelX = 20
    var panelY = 200
    var panelVisible = true
}
