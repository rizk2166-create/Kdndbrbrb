package com.demo.aimbot

import android.content.Context
import android.graphics.*
import android.view.View

class CrosshairView(context: Context) : View(context) {

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 2f, 2f, Color.BLACK)
    }

    private var detections: List<Detection> = emptyList()
    private var hasTarget = false

    fun updateDetections(list: List<Detection>, locked: Boolean) {
        detections = list
        hasTarget = locked
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f

        // ===== FOV CIRCLE =====
        if (Config.fovVisible) {
            val fovPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Config.fovColor
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            canvas.drawCircle(cx, cy, Config.fovRadius, fovPaint)
        }

        // ===== CROSSHAIR =====
        val color = if (hasTarget) Config.crosshairLockColor else Config.crosshairColor
        strokePaint.color = color
        strokePaint.strokeWidth = Config.crosshairThickness
        fillPaint.color = color

        val size = Config.crosshairSize
        val gap = Config.crosshairGap

        when (Config.crosshairStyle) {
            "cross" -> {
                drawCross(canvas, cx, cy, size, gap)
                if (Config.crosshairDot) canvas.drawCircle(cx, cy, Config.crosshairDotRadius, fillPaint)
            }
            "dot" -> {
                canvas.drawCircle(cx, cy, Config.crosshairDotRadius, fillPaint)
            }
            "circle" -> {
                strokePaint.style = Paint.Style.STROKE
                canvas.drawCircle(cx, cy, size, strokePaint)
                if (Config.crosshairDot) canvas.drawCircle(cx, cy, Config.crosshairDotRadius, fillPaint)
            }
            "tstyle" -> {
                // T-shape: 3 garis (kiri, kanan, bawah)
                canvas.drawLine(cx - gap - size, cy, cx - gap, cy, strokePaint)
                canvas.drawLine(cx + gap, cy, cx + gap + size, cy, strokePaint)
                canvas.drawLine(cx, cy + gap, cx, cy + gap + size, strokePaint)
                if (Config.crosshairDot) canvas.drawCircle(cx, cy, Config.crosshairDotRadius, fillPaint)
            }
        }

        // outline crosshair (opsional)
        if (Config.crosshairOutline) {
            val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                style = Paint.Style.STROKE
                strokeWidth = Config.crosshairThickness + 2f
            }
            // gambar ulang crosshair dengan outline (skip — simplifikasi)
        }

        // ===== BOUNDING BOX =====
        if (Config.showBox) {
            val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Config.boxColor
                style = Paint.Style.STROKE
                strokeWidth = Config.boxThickness
            }
            for (d in detections) {
                canvas.drawRect(d.x, d.y, d.x + d.w, d.y + d.h, boxPaint)
                if (Config.showLabel) {
                    canvas.drawText(
                        "%.2f".format(d.confidence),
                        d.x, d.y - 8, textPaint
                    )
                }
            }
        }
    }

    private fun drawCross(canvas: Canvas, cx: Float, cy: Float, size: Float, gap: Float) {
        canvas.drawLine(cx, cy - gap - size, cx, cy - gap, strokePaint)  // atas
        canvas.drawLine(cx, cy + gap, cx, cy + gap + size, strokePaint)  // bawah
        canvas.drawLine(cx - gap - size, cy, cx - gap, cy, strokePaint)  // kiri
        canvas.drawLine(cx + gap, cy, cx + gap + size, cy, strokePaint)  // kanan
    }
}
